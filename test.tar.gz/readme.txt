Just enter make to compile the test program
then enter ./test to run 
