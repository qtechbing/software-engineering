/**************************************************************************************************/
/* Copyright (C)             SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Fengshibing                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  test linktable                                                       */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fengshibing, 2014/09/30
 *
 */


#include<stdio.h>
#include"menu.h"

#define debug

int results[8] = {1,1,1,1,1,1,1,1};
char * info[8] =
{
    "test report",
    "TC1 CreateLinkTable",
    "TC2 AddLinkTableNode",
    "TC3 SearchLinkTableNode",
    "TC4 GetLinkTableHead",
    "TC5 GetNextLinkTableNode",
    "TC6 DelLinkTableNode",
    "TC7 DeleteLinkTable"
};

int main()
{
    int i,ret;
    tLinkTableNode* r;
    tLinkTable *p = CreateLinkTable();
    if(p == NULL)
    {
        debug("TC1 fail\n");
        results[1] = 1;
    }
    tLinkTableNode * pNode = NULL;   
    ret = AddLinkTableNode(p,pNode);
    if(ret == FAILURE)
    {
        debug("TC2 Succ\n");
        results[2] = 0;       
    }
    
    r=SearchLinkTableNode(p,NULL);
    if(r == NULL)
    {
        debug("TC3 fail\n");
        results[3] = 1;
    }
    
    r=GetLinkTableHead(p);
    if(r == NULL)
    {
        debug("TC4 fail\n");
        results[4] = 1;
    }
    
    r=GetNextLinkTableNode(p,pNode);
    if(r == NULL)
    {
        debug("TC5 fail\n");
        results[5] = 1;
    }
    
    ret=DelLinkTableNode(p,pNode);
    if(ret == FAILURE)
    {
        debug("TC6 Succ\n");
        results[6] = 0;
    }
    
    ret= DeleteLinkTable(p);
    if(ret == FAILURE)
    {
        debug("TC7 Succ\n");
        results[7] = 0;
    }

    /* test report */
    printf("test report\n");
    for(i=1;i<8;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
        else if(results[i] == 0)
        {
            printf("Testcase Number%d S - %s\n",i,info[i]);
        }
    }
}
